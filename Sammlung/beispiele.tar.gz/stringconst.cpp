#include "string1.h"

main()
{
    const String cs("Konstante");
    cs.print();
    //cs.set("Aenderung");   // nicht zulaessig
}
