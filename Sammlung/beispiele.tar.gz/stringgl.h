#include "string1.h"

extern String global1;  // Deklaration
extern String global2;  // Deklaration
extern void printg1(); // Deklaration

