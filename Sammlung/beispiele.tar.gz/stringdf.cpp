#include "stringgl.h"

String global1;             // Definition
String global2("Hallo");    // Definition

void printg1()              // Definition
{
   cout << "global1 = ";
   global1.print();
}


